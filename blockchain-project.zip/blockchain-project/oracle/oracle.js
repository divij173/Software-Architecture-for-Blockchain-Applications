const Web3 = require("web3");
const MongoClient = require("mongodb").MongoClient;

/**
 * This is url of our cluster inside mongodb
 */
const dbURI =
  "mongodb+srv://senospear:F2nnvYxGKU1Ii50i@cluster.npwagiw.mongodb.net/?retryWrites=true&w=majority";

(async () => {
  const web3Provider = new Web3.providers.WebsocketProvider(
    "ws://localhost:7545"
  );
  const web3 = new Web3(web3Provider);

  const account = web3.eth.accounts.wallet.add("0x" + "TODO");

  /**
   * Enter the address of the smart contract where you have deployed
   */
  addressOfRegistrationSmartContract = "TODO";
  addressOfMarketplaceSmartContract = "TODO";

  const registrationABI = require("./contracts/LandRegistrationAndVerification.sol");
  const marketplaceABI = require("./contracts/Marketplace.sol");

  const registrationContract = new web3.eth.Contract(
    registrationABI,
    addressOfRegistrationSmartContract
  );
  const marketplaceContract = new web3.eth.Contract(
    marketplaceABI,
    addressOfMarketplaceSmartContract
  );

  console.log(
    "Listening on Contract Addresses : Auth = " +
      addressOfRegistrationSmartContract +
      " : Val = " +
      addressOfMarketplaceSmartContract
  );
  listener(registrationContract, marketplaceContract, account, gasEstimates);
})();

function listener(registrationContract) {
  const acountCreatedHandler = registrationContract.events.AccountCreated(
    (error, event) => {
      if (error) throw error;

      console.log("Event Called : AccountCreated");

      MongoClient.connect(dbURI, function (err, client) {
        if (err) throw err;
        /**
         * Name of our collection
         */
        let db = client.db("LandRegistration");
        let myobj = {
          id: event.returnValues.clientIdentifier,
          name: event.returnValues.name,
          age: event.returnValues.age,
          city: event.returnValues.city,
          ssn: event.returnValues.ssn,
          email: event.returnValues.email,
        };

        db.collection("RegistrationDetails")
          .find({ id: myobj.id })
          .toArray((err, result) => {
            if (err) throw err;
            if (result.length > 0) {
              db.collection("RegistrationDetails").deleteOne(
                { id: myobj.id },
                function (err, obj) {
                  if (err) throw err;
                  console.log(
                    "Event Update : Account Created\n  - Pre-existing values found and deleted"
                  );
                }
              );
            }
          });

        db.collection("RegistrationDetails").insertOne(
          myobj,
          function (err, result) {
            if (err) throw err;
            console.log("Event Completed : AccountCreated");
            console.log("  Result:\n    id: " + myobj.id);
            client.close;
          }
        );
      });
    }
  );
}
