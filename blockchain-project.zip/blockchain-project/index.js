const { ethers } = require("ethers");
const readlineSync = require("readline-sync");

const contractAddress = "CONTRACT_ADDRESS";
const contractABI = [
  // Replace the ABI here
];

// Replace with etherium node url
const provider = new ethers.providers.JsonRpcProvider(
  "https://rinkeby.infura.io/v3/YOUR_INFURA_API_KEY"
);

const privateKey = "YOUR_PRIVATE_KEY"; // Replace with your private key

const wallet = new ethers.Wallet(privateKey, provider);
const contract = new ethers.Contract(contractAddress, contractABI, wallet);

async function main() {
  console.log("Welcome to the Land Title Management CLI!");
  const account = await wallet.getAddress();
  console.log("Your Ethereum address:", account);

  while (true) {
    console.log("\nSelect an option:");
    console.log("1. Register a new person");
    console.log("2. Update person details");
    console.log("3. Register land");
    console.log("4. List land for sale");
    console.log("5. Buy land");
    console.log("6. Verify a person");
    console.log("7. Verify land");
    console.log("8. Check if person is a seller");
    console.log("0. Exit");

    const option = readlineSync.question("Enter your choice: ");
    switch (option) {
      case "1":
        await registerPerson();
        break;
      case "2":
        await updatePersonDetails();
        break;
      case "3":
        await registerLand();
        break;
      case "4":
        await listLand();
        break;
      case "5":
        await buyLand();
        break;
      case "6":
        await verifyPerson();
        break;
      case "7":
        await verifyLand();
        break;
      case "8":
        await checkIfPersonIsSeller();
        break;
      case "0":
        console.log("Goodbye!");
        return;
      default:
        console.log("Invalid option. Try again.");
    }
  }
}

async function registerPerson() {
  console.log("\nRegister a new person:");

  const name = readlineSync.question("Enter person's name: ");
  const age = readlineSync.questionInt("Enter person's age: ");
  const ssn = readlineSync.question("Enter person's SSN: ");
  const email = readlineSync.question("Enter person's email: ");
  const city = readlineSync.question("Enter person's city: ");

  try {
    const transaction = await contract.addPerson(name, age, ssn, email, city);
    const receipt = await transaction.wait();
    if (receipt.status === 1) {
      console.log("Person registered successfully!");
    } else {
      console.log("Failed to register person.");
    }
  } catch (error) {
    console.error("Error registering person:", error.message);
  }
}

async function registerLand() {
  console.log("\nRegister a new land:");

  const id = readlineSync.questionInt("Enter land ID: ");
  const current_owner = readlineSync.question(
    "Enter current owner's Ethereum address: "
  );
  const price = readlineSync.questionInt("Enter land price: ");
  const location = readlineSync.question("Enter land location: ");
  const post_code = readlineSync.questionInt("Enter land post code: ");

  try {
    const transaction = await contract.registerLand(
      id,
      current_owner,
      price,
      location,
      post_code
    );
    const receipt = await transaction.wait();
    if (receipt.status === 1) {
      console.log("Land registered successfully!");
    } else {
      console.log("Failed to register land.");
    }
  } catch (error) {
    console.error("Error registering land:", error.message);
  }
}

async function listLand() {
  console.log("\nList a land for sale:");

  const land_id = readlineSync.questionInt("Enter the land ID: ");
  const price = readlineSync.questionInt("Enter the sale price: ");

  try {
    const transaction = await contract.listLand(land_id, price);
    const receipt = await transaction.wait();
    if (receipt.status === 1) {
      console.log("Land listed for sale successfully!");
    } else {
      console.log("Failed to list land for sale.");
    }
  } catch (error) {
    console.error("Error listing land for sale:", error.message);
  }
}

async function buyLand() {
  console.log("\nBuy a land:");

  const land_id = readlineSync.questionInt("Enter the land ID: ");

  try {
    const transaction = await contract.buyLand(land_id, {
      value: ethers.utils.parseEther("0.1"),
    }); // Replace 0.1 with the amount of Ether you want to send for the purchase
    const receipt = await transaction.wait();
    if (receipt.status === 1) {
      console.log("Land purchased successfully!");
    } else {
      console.log("Failed to buy land.");
    }
  } catch (error) {
    console.error("Error buying land:", error.message);
  }
}

async function verifyPerson() {
  console.log("\nVerify a person:");

  const personAddress = readlineSync.question(
    "Enter the Ethereum address of the person to verify: "
  );

  try {
    const transaction = await contract.verifyPerson(personAddress);
    const receipt = await transaction.wait();
    if (receipt.status === 1) {
      console.log("Person verified successfully!");
    } else {
      console.log("Failed to verify person.");
    }
  } catch (error) {
    console.error("Error verifying person:", error.message);
  }
}

async function verifyLand() {
  console.log("\nVerify a land:");

  const land_id = readlineSync.questionInt("Enter the land ID to verify: ");

  try {
    const transaction = await contract.verifyLand(land_id);
    const receipt = await transaction.wait();
    if (receipt.status === 1) {
      console.log("Land verified successfully!");
    } else {
      console.log("Failed to verify land.");
    }
  } catch (error) {
    console.error("Error verifying land:", error.message);
  }
}

async function checkIfPersonIsSeller() {
  console.log("\nCheck if a person is a seller:");

  const personAddress = readlineSync.question(
    "Enter the Ethereum address of the person: "
  );

  try {
    const isSeller = await contract.personIsSeller(personAddress);
    if (isSeller) {
      console.log("The person is a seller.");
    } else {
      console.log("The person is not a seller.");
    }
  } catch (error) {
    console.error("Error checking if person is a seller:", error.message);
  }
}

main().catch((err) => console.error(err));
